#!/bin/bash
expect datasenders/senddata.exp && expect datasenders/senddata2.exp && expect datasenders/senddata3.exp && expect datasenders/senddata4.exp && expect datasenders/senddata5.exp && expect datasenders/senddata6.exp && expect datasenders/senddata7.exp
